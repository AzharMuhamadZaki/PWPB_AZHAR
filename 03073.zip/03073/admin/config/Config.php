<?php

define('baseurl','http://localhost/latihan_ukkazhar/public');

//DB
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','latihan_ukkazhar');
